public class ProductionTile {
	protected enum Terrain {
		DESERT, SWAMP, FOREST, FERTILE, HILLS, MOUNTAINS
	};

	Terrain type;
	protected int[] resource;
	protected int quantity;

	public ProductionTile(ProductionTile.Terrain terrain, int food, int wood,
			int gold, int favor, int quantity) {
		resource = new int[4];
		type = terrain;
		resource[0] = food;
		resource[1] = wood;
		resource[2] = gold;
		resource[3] = favor;
		this.quantity = quantity;
	}
	
	@Override
	public String toString(){
		String resources = "";
		for(int i = 0; i < resource.length; i ++){
			if(resource[i] > 0){
				resources = resources + resource[i];
				switch(i){
					case 0: 
						resources = resources + " Food";
						break;
					case 1: 
						resources = resources + " Wood";
						break;
					case 2: 
						resources = resources + " Gold";
						break;
					case 3: 
						resources = resources + " Favor";
						break;
					default: break;
				}
			}
		}
		return ("" + type + " : " + resources);
	}
}
