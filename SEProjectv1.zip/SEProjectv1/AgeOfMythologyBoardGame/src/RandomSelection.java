import java.util.ArrayList;
import java.util.Random;


public class RandomSelection <T>{
	ArrayList<T> selections;
	public RandomSelection(ArrayList<T> list){
		selections = list;
	}
	
	public T getRandomFromList () {
		Random rand = new Random();
		int index = rand.nextInt(selections.size());
		T temp = selections.get(index);
		selections.remove(index);
		return temp;
		
	}
}
